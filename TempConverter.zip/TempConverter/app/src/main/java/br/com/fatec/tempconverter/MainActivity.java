package br.com.fatec.tempconverter;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.app.Activity;
import android.widget.Toast;
import java.text.DecimalFormat;
import java.text.NumberFormat;



public class MainActivity extends Activity {
    private EditText text;
    private TextView result;

    //TextView text = (TextView) findViewById(R.id.text);
    //EditText et1 = (EditText) findViewById(R.id.editText1);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        NumberFormat decimalFormat = new DecimalFormat(".##");
        text=(EditText) findViewById(R.id.editText1);
        result=(TextView)findViewById(R.id.resultado);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    }
        
        public void converter(View v) {

        switch (v.getId()) {
            case R.id.Button:
                RadioButton cb = (RadioButton) findViewById(R.id.cb1);
                RadioButton cb2 = (RadioButton) findViewById(R.id.cb2);
                RadioButton fb = (RadioButton) findViewById(R.id.fb1);
                RadioButton fb2 = (RadioButton) findViewById(R.id.fb2);
                RadioButton kv = (RadioButton) findViewById(R.id.kv1);
                RadioButton kv2 = (RadioButton) findViewById(R.id.kv2);

                if (text.getText().length() == 0) {
                    Toast.makeText(this, "Entre com os dados",
                            Toast.LENGTH_LONG).show();
                    return;
                }
                double temp = Double.parseDouble(text.getText().toString());
                //check which radio button is checked
                if (cb.isChecked() && fb2.isChecked()) {
                    //display conversion
                    result.setText(String.valueOf(c2f(temp)) + " °F");
                    //cb.setChecked(false);
                    //fb2.setChecked(true);
                } else if (cb.isChecked() && kv2.isChecked()) {

                    result.setText(String.valueOf(c2k(temp)) + " K");
                    //cb.setChecked(false);
                    //kv2.setChecked(true);
                } else if (cb.isChecked() && cb2.isChecked()) {
                    Toast.makeText(MainActivity.this, "Escolha uma unidade diferente", Toast.LENGTH_LONG).show();
                    //text.setText(et1.getText().toString()+" C");
                    //cb.setChecked(false);
                    // cb2.setChecked(false);
                } else if (fb.isChecked() && cb2.isChecked()) {

                    result.setText(String.valueOf(f2c(temp)) + " °C");
                    //fb.setChecked(false);
                    //cb2.setChecked(true);
                } else if (fb.isChecked() && kv2.isChecked()) {

                    result.setText(String.valueOf(f2k(temp)) + " K");

                    //fb.setChecked(false);
                    //kv2.setChecked(true);
                } else if (fb.isChecked() && fb2.isChecked()) {

                    Toast.makeText(MainActivity.this, "Escolha uma unidade diferente", Toast.LENGTH_LONG).show();
                    //fb.setChecked(false);
                    //fb2.setChecked(false);
                } else if (kv.isChecked() && cb2.isChecked()) {

                    result.setText(String.valueOf(k2c(temp)) + " °C");
                    //kv.setChecked(false);
                    //cb2.setChecked(true);
                } else if (kv.isChecked() && fb2.isChecked()) {

                    result.setText(String.valueOf(k2f(temp)) + " °F");

                    //kv.setChecked(false);
                    //fb2.setChecked(true);
                } else if (kv.isChecked() && kv2.isChecked()) {

                    Toast.makeText(MainActivity.this, "Escolha uma unidade diferente", Toast.LENGTH_LONG).show();
                    //kv.setChecked(false);
                    //kv2.setChecked(true);
                }
                break;

        }
        }
    //Celcius to Fahrenhiet method
    private double c2f(double k)
    {
        return ((9*k + 160)/5);
    }
    //Fahrenhiet to Celcius method
    private double f2c(double k)
    {
        return ((5*(k - 32))/9);
    }
    private double k2c(double k)
    {
        return (k - 273);
    }

    private double c2k(double k) {

        if (k + 273 < 0) {
            return 0;
        } else {
            return k + 273;
        }
    }
    private double k2f(double k) {
        return ((9*k - 2297)/5);
    }

    private double f2k(double k) {

        if (((5*k + 2297)/9)< 0) {
            return 0;
        } else {
            return ((5*k + 2297)/9);
        }
    }
}



