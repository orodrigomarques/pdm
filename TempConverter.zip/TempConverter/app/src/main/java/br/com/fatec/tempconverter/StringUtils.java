package br.com.fatec.tempconverter;


import android.view.View;

/**
 * Created by marques on 25/08/16.
 */
public class StringUtils {

    public static final boolean isNullOREmpty(String str){

        return str == null || str.length()==0;

    }
}
